This is the javascript version of one of our previous framework named ARCS for
Augmented Reality Component System. Many of the concepts are those
developped for the original engine and can be read in 
[this page](http://arcs.ibisc.univ-evry.fr/). 
The javascript ARCS engine is intended to run on both server side in a 
[Node.js](http://nodejs.org/) environment or inside a web browser. 
 
